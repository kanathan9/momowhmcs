<?php

$amount = (int) $_POST['amount'];
$number = $_POST['number'];
$GetData = array("idbouton"=>"2", "typebouton"=>"PAIE", "_amount"=>$amount, "_tel"=>$number, "_clP"=>'4scfLxWMOd', "_email"=>'mobilepayment@globexcam.com');
                $suiteUrl = http_build_query($GetData);
                $ch0 = curl_init();
                curl_setopt($ch0, CURLOPT_URL, "https://developer.mtn.cm/OnlineMomoWeb/faces/transaction/transactionRequest.xhtml?".$suiteUrl);
                curl_setopt($ch0, CURLOPT_RETURNTRANSFER, 1);
                //curl_setopt($ch0, CURLOPT_CUSTOMREQUEST, "GET");
                //curl_setopt($ch0, CURLOPT_POST, 1);
                //curl_setopt($ch0, CURLOPT_POSTFIELDS, json_encode($GetData));
                $response = curl_exec($ch0);
                $err = curl_error($ch0);
                $httpCode = curl_getinfo($ch0, CURLINFO_HTTP_CODE);
                $responseBody = json_decode($response);
                curl_close($ch0);echo 'here3';var_dump($httpCode);
                if($responseBody->StatusCode==01){
                    //Success action here
                    $status = true;
                    $transactionId = $responseBody->TransactionID;echo 'here4';
                }else{
                    //Failure action here
                    $status = false;
                    $transactionId = null;echo 'here5';
                }
                echo $responseBody;
                // $postData = array("x_status"=>$status, "x_invoice_id"=>$invoiceId, "x_trans_id"=>$transactionId, "x_amount"=>$amount, "x_fee"=>0, "x_hash"=>md5($invoiceId . $transactionId . $amount . $secret));
                // $postData = http_build_query($postData);
                // $ch1 = curl_init();
                // curl_setopt($ch1, CURLOPT_URL, urldecode($callbackUrl));
                // curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
                // // curl_setopt($ch0, CURLOPT_CUSTOMREQUEST, "POST");
                // curl_setopt($ch1, CURLOPT_POST, 1);
                // curl_setopt($ch1, CURLOPT_POSTFIELDS, $postData);
                // curl_exec($ch1);echo'here6';

?>