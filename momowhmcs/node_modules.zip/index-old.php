<?php


if(isset($_POST['amount']) && isset($_POST['step']) && $_POST['step']==1){
    $amount= $_POST['amount'];

    $htmlOutput = 'Payer '.$amount.' à CloudHost pour la facture N.'.$_POST['invoice_id'].' <br>';
    $htmlOutput .= '<form method="POST" action="">';
    $htmlOutput .= '<select name="operator">';
    $htmlOutput .= '<option value="mtn">MTN MOBILE MONEY</option>';
    $htmlOutput .= '<option value="orange">ORANGE MONEY</option>';
    $htmlOutput .= '<option value="express">EXPRESS UNION MOBILE MONEY</option>';
    $htmlOutput .= '</select>';
    $htmlOutput .= '<input type="number" name="number">';
    $htmlOutput .= '<input type="hidden" name="amount" value="'.$amount.'">';
    $htmlOutput .= '<input type="hidden" name="step" value="2">';
    $htmlOutput .= '<input type="hidden" name="api" value="'.$_POST['api'].'">';
    $htmlOutput .= '<input type="hidden" name="invoice_id" value="'.$_POST['invoice_id'].'">';
    $htmlOutput .= '<input type="hidden" name="description" value="'.$_POST['description'].'">';
    $htmlOutput .= '<input type="hidden" name="callback_url" value="'.$_POST['callback_url'].'">';
    $htmlOutput .= '<input type="submit" value="PAY" />';
    $htmlOutput .= '</form>';

    echo $htmlOutput;

}elseif(isset($_POST['amount']) && isset($_POST['step']) && $_POST['step']==2){
    if(isset($_POST['api']) && isset($_POST['number']) && isset($_POST['operator']) && isset($_POST['invoice_id']) && isset($_POST['callback_url'])){
        $api = $_POST['api'];
        $callbackUrl = $_POST['callback_url'];
        $invoiceId = $_POST['invoice_id'];
        $number = $_POST['number'];
        $operator = $_POST['operator'];
        $amount = (int) $_POST['amount'];
        echo 'here2';
        if($api == 'monetbil'){

        }else{
            if($operator == 'mtn'){
                $GetData = array("idbouton"=>"2", "typebouton"=>"PAIE", "_amount"=>$amount, "_tel"=>$number, "_clP"=>'4scfLxWMOd', "_email"=>'mobilepayment@globexcam.com');
                $suiteUrl = http_build_query($GetData);
                $ch0 = curl_init();
                curl_setopt($ch0, CURLOPT_URL, "https://developer.mtn.cm/OnlineMomoWeb/faces/transaction/transactionRequest.xhtml?".$suiteUrl);
                curl_setopt($ch0, CURLOPT_RETURNTRANSFER, 1);
                //curl_setopt($ch0, CURLOPT_CUSTOMREQUEST, "GET");
                //curl_setopt($ch0, CURLOPT_POST, 1);
                //curl_setopt($ch0, CURLOPT_POSTFIELDS, json_encode($GetData));
                $response = curl_exec($ch0);
                $err = curl_error($ch0);
                $httpCode = curl_getinfo($ch0, CURLINFO_HTTP_CODE);
                $responseBody = json_decode($response);
                curl_close($ch0);echo 'here3';var_dump($httpCode);
                if($responseBody->StatusCode==01){
                    //Success action here
                    $status = true;
                    $transactionId = $responseBody->TransactionID;echo 'here4';
                }else{
                    //Failure action here
                    $status = false;
                    $transactionId = null;echo 'here5';
                }
                $postData = array("x_status"=>$status, "x_invoice_id"=>$invoiceId, "x_trans_id"=>$transactionId, "x_amount"=>$amount, "x_fee"=>0, "x_hash"=>md5($invoiceId . $transactionId . $amount . $secret));
                $postData = http_build_query($postData);
                $ch1 = curl_init();
                curl_setopt($ch1, CURLOPT_URL, urldecode($callbackUrl));
                curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
                // curl_setopt($ch0, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($ch1, CURLOPT_POST, 1);
                curl_setopt($ch1, CURLOPT_POSTFIELDS, $postData);
                curl_exec($ch1);echo'here6';
            }elseif($operator == 'orange'){

            }elseif($operator == 'express'){

            }
        }
    }
}




?>